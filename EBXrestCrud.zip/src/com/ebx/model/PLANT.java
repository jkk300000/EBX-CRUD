package com.ebx.model;

import java.util.Date;

public class PLANT {
	private String SHOPID;
	private String SHOPNAME;
	private String SHOPDESC;
	private String SHOPIUSE;
	private String SITEID;
	private String ERPSHOPID;
	private String INSUSER;
	private Date INSDTTM; 
	private String UPDUSER;
	private Date UPDDTTM;
	
	public String getSHOPID() {
		return SHOPID;
	}
	public void setSHOPID(String sHOPID) {
		SHOPID = sHOPID;
	}
	public String getSHOPNAME() {
		return SHOPNAME;
	}
	public void setSHOPNAME(String sHOPNAME) {
		SHOPNAME = sHOPNAME;
	}
	public String getSHOPDESC() {
		return SHOPDESC;
	}
	public void setSHOPDESC(String sHOPDESC) {
		SHOPDESC = sHOPDESC;
	}
	public String getSHOPIUSE() {
		return SHOPIUSE;
	}
	public void setSHOPIUSE(String sHOPIUSE) {
		SHOPIUSE = sHOPIUSE;
	}
	public String getSITEID() {
		return SITEID;
	}
	public void setSITEID(String sITEID) {
		SITEID = sITEID;
	}
	public String getERPSHOPID() {
		return ERPSHOPID;
	}
	public void setERPSHOPID(String eRPSHOPID) {
		ERPSHOPID = eRPSHOPID;
	}
	public String getINSUSER() {
		return INSUSER;
	}
	public void setINSUSER(String iNSUSER) {
		INSUSER = iNSUSER;
	}
	public Date getINSDTTM() {
		return INSDTTM;
	}
	public void setINSDTTM(Date iNSDTTM) {
		INSDTTM = iNSDTTM;
	}
	public String getUPDUSER() {
		return UPDUSER;
	}
	public void setUPDUSER(String uPDUSER) {
		UPDUSER = uPDUSER;
	}
	public Date getUPDDTTM() {
		return UPDDTTM;
	}
	public void setUPDDTTM(Date uPDDTTM) {
		UPDDTTM = uPDDTTM;
	} 
	
	

}
