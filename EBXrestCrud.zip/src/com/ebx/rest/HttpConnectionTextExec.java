package com.ebx.rest;


import java.text.ParseException;
import java.util.HashMap;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.glassfish.jersey.media.sse.SseFeature;
import org.json.simple.JSONObject;

import com.onwbp.com.fasterxml.jackson.databind.ObjectMapper;





public class HttpConnectionTextExec {

	
	
	public static void main(String[] args) throws Exception {
		
		//getData();
		//updateData();
		//deleteData();
		createData();
		

	}
	
	// get data from URL
    
	public static void getData() {
	Client restClient = ClientBuilder.newClient();
    HttpAuthenticationFeature basicAuthFeature = HttpAuthenticationFeature.basic("admin", "admin");
    restClient.register(basicAuthFeature);
    restClient.register(SseFeature.class);
    WebTarget target = restClient.target("http://localhost:8080/ebx-dataservices/rest/data/v1/BLGES-MMD/LGES_MMD/root/PLANT");
    		 			 
    Invocation.Builder invoker = target.request(MediaType.APPLICATION_JSON);
    Response response = invoker.get();
    					
    String actual = response.readEntity(String.class) ;       
    
    System.out.println(response);
    System.out.println(actual.toString());
    
	}
  
	// put data from URL
	
	public static void updateData() throws ParseException {
		
		Client restClient = ClientBuilder.newClient();
	    HttpAuthenticationFeature basicAuthFeature = HttpAuthenticationFeature.basic("admin", "admin");
	    restClient.register(basicAuthFeature);
	    restClient.register(SseFeature.class);
	    WebTarget target = restClient.target("http://localhost:8080/ebx-dataservices/rest/data/v1/BLGES-MMD/LGES_MMD/root/PLANT/A001/SHOPNAME");
		
	    HashMap<String,Object> additionalDetails = new HashMap<String,Object>();
	    additionalDetails.put("content", "��â 10 ����");
	    
	    JSONObject jsonObject = new JSONObject(additionalDetails);

	    
	    System.out.println(jsonObject);
	    
	    
	    
	    Invocation.Builder invoker = target.request(MediaType.APPLICATION_JSON);
	    Response response = invoker.put(Entity.entity(jsonObject, MediaType.APPLICATION_JSON));
	    					
	    String actual = response.readEntity(String.class) ;       
	    
	    System.out.println(response);
	    System.out.println(actual);
		
	}
	
	public static void deleteData() {
		
		Client restClient = ClientBuilder.newClient();
	    HttpAuthenticationFeature basicAuthFeature = HttpAuthenticationFeature.basic("admin", "admin");
	    restClient.register(basicAuthFeature);
	    restClient.register(SseFeature.class);
	    WebTarget target = restClient.target("http://localhost:8080/ebx-dataservices/rest/data/v1/BLGES-MMD/LGES_MMD/root/PLANT/A001");
		
	    Invocation.Builder invoker = target.request(MediaType.APPLICATION_JSON);
	    Response response = invoker.delete();
	    					
	    String actual = response.readEntity(String.class) ;       
	    
	    System.out.println(response);
	    System.out.println(actual.toString());
		
	}
	
	public static void createData() {
		
		Client restClient = ClientBuilder.newClient();
	    HttpAuthenticationFeature basicAuthFeature = HttpAuthenticationFeature.basic("admin", "admin");
	    restClient.register(basicAuthFeature);
	    restClient.register(SseFeature.class);
	    WebTarget target = restClient.target("http://localhost:8080/ebx-dataservices/rest/data/v1/BLGES-MMD/LGES_MMD/root/PLANT");
		
	    HashMap<String,Object> SHOPIDdataMap = new HashMap<String,Object>();
	    SHOPIDdataMap.put("content", "A001");
	    JSONObject SHOPIDdata = new JSONObject(SHOPIDdataMap);
	    
	    HashMap<String,Object> SHOPNAMEdataMap = new HashMap<String,Object>();
	    SHOPNAMEdataMap.put("content", "��â 1����");
	    JSONObject SHOPNAMEdata = new JSONObject(SHOPNAMEdataMap);
	    
	    HashMap<String,Object> SHOPDESCdataMap = new HashMap<String,Object>();
	    SHOPDESCdataMap.put("content", "�������������");
	    JSONObject SHOPDESCdata = new JSONObject(SHOPDESCdataMap);
	    
	    HashMap<String,Object> SHOPIUSEdataMap = new HashMap<String,Object>();
	    SHOPIUSEdataMap.put("content", "Y");
	    JSONObject SHOPIUSEdata = new JSONObject(SHOPIUSEdataMap);
	    
	    HashMap<String,Object> SITEIDdataMap = new HashMap<String,Object>();
	    SITEIDdataMap.put("content", "S001");
	    JSONObject SITEIDdata = new JSONObject(SITEIDdataMap);
	    
	    HashMap<String,Object> ERPSHOPdataMap = new HashMap<String,Object>();
	    ERPSHOPdataMap.put("content", "A001");
	    JSONObject ERPSHOPdata = new JSONObject(ERPSHOPdataMap);
	    
	    HashMap<String,Object> INSUSERdataMap = new HashMap<String,Object>();
	    INSUSERdataMap.put("content", "Admin");
	    JSONObject INSUSERdata = new JSONObject(INSUSERdataMap);
	    
	    HashMap<String,Object> INSDTTMdataMap = new HashMap<String,Object>();
	    INSDTTMdataMap.put("content", "2023-02-16T11:30:01.000");
	    JSONObject INSDTTMdata = new JSONObject(INSDTTMdataMap);
	    
	    HashMap<String,Object> UPDUSERdataMap = new HashMap<String,Object>();
	    UPDUSERdataMap.put("content", "Admin");
	    JSONObject UPDUSERdata = new JSONObject(UPDUSERdataMap);
	    
	    HashMap<String,Object> UPDDTTMdataMap = new HashMap<String,Object>();
	    UPDDTTMdataMap.put("content", "2023-02-16T11:30:01.000");
	    JSONObject UPDDTTMdata = new JSONObject(UPDDTTMdataMap);
	    
	    HashMap<String,Object> PLANTdataMap = new HashMap<String,Object>();
	    PLANTdataMap.put("SHOPID", SHOPIDdata);

	    PLANTdataMap.put("SHOPNAME", SHOPNAMEdata);

	    PLANTdataMap.put("SHOPDESC", SHOPDESCdata);

	    PLANTdataMap.put("SHOPIUSE", SHOPIUSEdata);
	
	    PLANTdataMap.put("SITEID", SITEIDdata);

	    PLANTdataMap.put("ERPSHOPID", ERPSHOPdata);

	    PLANTdataMap.put("INSUSER", INSUSERdata);

	    PLANTdataMap.put("INSDTTM", INSDTTMdata);

	    PLANTdataMap.put("UPDUSER", UPDUSERdata);

	    PLANTdataMap.put("UPDDTTM", UPDDTTMdata);
	    
	    JSONObject PLANTdata = new JSONObject(PLANTdataMap);
	    
	    
	    HashMap<String,Object> finalPLANTdataMap = new HashMap<String,Object>();
	    finalPLANTdataMap.put("content", PLANTdata);
	    JSONObject finalPLANTdata = new JSONObject(finalPLANTdataMap);
	    

	    
	    System.out.println(finalPLANTdata);
	   
	    
	    Invocation.Builder invoker = target.request(MediaType.APPLICATION_JSON);
	    Response response = invoker.post(Entity.entity(finalPLANTdata, MediaType.APPLICATION_JSON));
	    					
	    String actual = response.readEntity(String.class) ;       
	    
	    System.out.println(response);
	    System.out.println(actual.toString());
		
	}

}
